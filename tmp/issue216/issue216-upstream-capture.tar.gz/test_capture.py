import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parent
WRAPPER = ROOT / 'capture_codex.py'
spec = importlib.util.spec_from_file_location('capture', WRAPPER)
capture = importlib.util.module_from_spec(spec)
spec.loader.exec_module(capture)
SECRET = 'TOP_SECRET_PROMPT_BODY'

class CaptureTests(unittest.TestCase):
    def setup_process(self, extra):
        tmp = tempfile.TemporaryDirectory()
        self.addCleanup(tmp.cleanup)
        root = Path(tmp.name)
        fake = root / 'codex'
        fake.write_text('''#!/usr/bin/env python3
import sys, os, json, time
if sys.argv[1:] == ['--version']:
 print('codex-cli 0.163.0'); sys.exit(0)
''' + extra)
        fake.chmod(0o700)
        return root, dict(os.environ, ISSUE216_CODEX_BIN=str(fake), ISSUE216_CAPTURE_DIR=str(root))

    def records(self, root):
        paths = list(root.glob('capture-*.jsonl'))
        self.assertEqual(len(paths), 1)
        self.assertEqual(paths[0].stat().st_mode & 0o777, 0o600)
        text = paths[0].read_text()
        self.assertNotIn(SECRET, text)
        return [json.loads(x) for x in text.splitlines()]

    def test_projection_omits_all_bodies_and_spans(self):
        row = capture.project({'target': 'codex_api::responses_websocket_timing', 'fields': {
            'thread_id': 'thread-123', 'turn_id': 'turn-456', 'payload': SECRET,
            'error.message': SECRET, 'prompt': SECRET, 'request_start_ms': '1234'}, 'spans': [SECRET]})
        self.assertEqual(row['thread_id'], 'thread-123')
        self.assertEqual(row['request_start_ms'], 1234)
        self.assertNotIn(SECRET, json.dumps(row))
        self.assertTrue(row['error_present'])
        self.assertIsNone(capture.project({'target': 'codex_otel.trace_safe', 'fields': {'event.name': 'codex.tool_result', 'output': SECRET}}))

    def test_passthrough_and_sanitization(self):
        root, env = self.setup_process('''
assert os.environ['LOG_FORMAT'] == 'json'
assert os.environ['RUST_LOG'].startswith('off,')
sys.stdout.buffer.write(sys.stdin.buffer.read())
print(json.dumps({'target':'codex_otel.trace_safe','fields':{'event.name':'codex.websocket_request','conversation.id':'thread-123','error.message':'TOP_SECRET_PROMPT_BODY','duration_ms':'7','success':'false'}}), file=sys.stderr)
print('TOP_SECRET_PROMPT_BODY', file=sys.stderr)
sys.exit(7)
''')
        data = b'\x00\xff{"protocol":"untouched"}\n'
        p = subprocess.run([str(WRAPPER), 'app-server', '--stdio'], input=data, capture_output=True, env=env, timeout=10)
        self.assertEqual(p.stdout, data)
        self.assertEqual(p.stderr, b'')
        self.assertEqual(p.returncode, 7)
        rows = self.records(root)
        self.assertEqual(rows[-1]['invalid_lines'], 1)
        self.assertEqual(rows[-1]['retained_events'], 1)
        self.assertEqual(rows[-1]['returncode'], 7)

    def test_oversized_line_recovers_and_counts(self):
        root, env = self.setup_process('''
print('X'*200000, file=sys.stderr)
print(json.dumps({'target':'codex_api::responses_websocket_timing','fields':{'thread_id':'thread-1'}}), file=sys.stderr)
''')
        p = subprocess.run([str(WRAPPER), 'app-server', '--stdio'], capture_output=True, env=env, timeout=10)
        self.assertEqual(p.returncode, 0)
        rows = self.records(root)
        self.assertEqual(rows[-1]['oversized_lines'], 1)
        self.assertEqual(rows[-1]['retained_events'], 1)

    def test_file_limit_still_drains_and_exits(self):
        root, env = self.setup_process('''
line=json.dumps({'target':'codex_api::responses_websocket_timing','fields':{'thread_id':'t'*150,'turn_id':'u'*150}})+'\\n'
sys.stderr.write(line*22000)
''')
        p = subprocess.run([str(WRAPPER), 'app-server', '--stdio'], capture_output=True, env=env, timeout=20)
        self.assertEqual(p.returncode, 0)
        rows = self.records(root)
        self.assertGreater(rows[-1]['omitted_events'], 0)
        self.assertLessEqual(next(root.glob('capture-*.jsonl')).stat().st_size, capture.MAX_FILE)

    def test_signal_forwards_and_records_cleanup(self):
        root, env = self.setup_process('time.sleep(30)\n')
        p = subprocess.Popen([str(WRAPPER), 'app-server', '--stdio'], stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=env)
        self.addCleanup(lambda: p.kill() if p.poll() is None else None)
        for _ in range(200):
            files = list(root.glob('capture-*.jsonl'))
            if files and 'child_started' in files[0].read_text():
                break
            time.sleep(.01)
        else:
            self.fail('child did not start')
        p.send_signal(signal.SIGTERM)
        out, err = p.communicate(timeout=10)
        self.assertEqual((out, err), (b'', b''))
        self.assertEqual(p.returncode, 143)
        self.assertEqual(self.records(root)[-1]['signal_received'], signal.SIGTERM)

    def test_version_passthrough_no_capture(self):
        root, env = self.setup_process('raise AssertionError()\n')
        p = subprocess.run([str(WRAPPER), '--version'], capture_output=True, env=env, timeout=10)
        self.assertEqual(p.stdout, b'codex-cli 0.163.0\n')
        self.assertEqual(list(root.glob('capture-*.jsonl')), [])

if __name__ == '__main__':
    unittest.main()
