#!/usr/bin/env python3
"""Temporary Codex 0.163.0 diagnostic launcher, not a business runtime replacement.

Set ISSUE216_CODEX_BIN to the real executable and ISSUE216_CAPTURE_DIR to a private
existing directory. Use this file as --codex-bin only in a new diagnostic identity.
Stdin/stdout are inherited byte-for-byte. Raw stderr is NEVER persisted or echoed.
Only selected metadata is written; this cannot observe every WebSocket frame.
"""
import datetime
import hashlib
import json
import math
import os
from pathlib import Path
import re
import signal
import stat
import subprocess
import sys
import time
import uuid

MAX_LINE = 65536
MAX_FILE = 8 * 1024 * 1024
FILTER = 'off,codex_otel.trace_safe=info,codex_api::responses_websocket_timing=trace,codex_api::endpoint::responses_websocket=info'
EVENTS = {'codex.api_request', 'codex.websocket_connect', 'codex.websocket_request', 'codex.sse_event', 'codex.auth_recovery'}
IDS = {'conversation.id', 'thread_id', 'turn_id', 'session_id', 'traceparent', 'previous_response_id', 'auth.request_id', 'auth.cf_ray', 'model', 'app.version'}
NUMBERS = {'duration_ms', 'attempt', 'http.response.status_code', 'request_start_ms'}
BOOLS = {'success', 'warmup', 'connection_reused', 'auth.connection_reused'}


def project(record):
    """Explicit projection, never retain message/payload/spans/unknown fields."""
    if not isinstance(record, dict) or not isinstance(record.get('fields'), dict):
        return None
    f = record['fields']
    target = record.get('target')
    event = f.get('event.name')
    if target == 'codex_api::responses_websocket_timing':
        event = 'responsesapi.websocket_timing'
    elif target == 'codex_otel.trace_safe' and event in EVENTS:
        pass
    elif target == 'codex_api::endpoint::responses_websocket' and f.get('message') in ('new', 'close'):
        span = record.get('span', {})
        if not isinstance(span, dict) or span.get('name') != 'responses_websocket.stream_request':
            return None
        event = 'responses_websocket.stream_request.' + f['message']
    else:
        return None
    out = {'event': event}
    timestamp = record.get('timestamp')
    if isinstance(timestamp, str) and re.fullmatch(r'[0-9T:.+Z-]{15,40}', timestamp):
        out['source_utc'] = timestamp
    for key in IDS:
        v = f.get(key)
        if isinstance(v, str) and re.fullmatch(r'[A-Za-z0-9_:/.-]{1,160}', v):
            out[key] = v
    for key in NUMBERS:
        v = f.get(key)
        if isinstance(v, str) and re.fullmatch(r'\d+(?:\.\d+)?', v):
            v = float(v) if '.' in v else int(v)
        if type(v) in (int, float) and math.isfinite(v) and 0 <= v < 1e18:
            out[key] = v
    for key in BOOLS:
        v = f.get(key)
        if type(v) is bool or v in ('true', 'false'):
            out[key] = v is True or v == 'true'
    kind = f.get('event.kind')
    if isinstance(kind, str) and re.fullmatch(r'(?:response\.[a-z_.]{1,80}|unknown|parse_error)', kind):
        out['event.kind'] = kind
    out['error_present'] = bool(f.get('error.message'))
    # Even timing payloads may evolve; retain no raw or recursively selected payload.
    return out


def main():
    real = Path(os.environ['ISSUE216_CODEX_BIN']).resolve(strict=True)
    if real == Path(__file__).resolve():
        raise ValueError('recursive launcher')
    args = sys.argv[1:]
    if args != ['app-server', '--stdio']:
        os.execv(str(real), [str(real), *args])
    version = subprocess.run([str(real), '--version'], capture_output=True, timeout=10, check=True)
    if version.stdout.strip() != b'codex-cli 0.163.0':
        raise ValueError('unsupported Codex version')
    root = Path(os.environ['ISSUE216_CAPTURE_DIR']).resolve(strict=True)
    mode = root.stat()
    if not stat.S_ISDIR(mode.st_mode) or mode.st_uid != os.getuid() or mode.st_mode & 0o077:
        raise ValueError('capture directory must be owned by current user and mode 0700')
    path = root / ('capture-' + str(os.getpid()) + '-' + uuid.uuid4().hex + '.jsonl')
    fd = os.open(path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
    start = time.monotonic()
    stats = {'stderr_bytes': 0, 'invalid_lines': 0, 'oversized_lines': 0, 'ignored_lines': 0, 'retained_events': 0, 'omitted_events': 0}
    written = 0
    child = None
    pending_signal = None

    def forward(signum, frame):
        nonlocal pending_signal
        pending_signal = signum
        if child is not None:
            try:
                child.send_signal(signum)
            except ProcessLookupError:
                pass

    signal.signal(signal.SIGTERM, forward)
    signal.signal(signal.SIGINT, forward)
    with os.fdopen(fd, 'w', buffering=1) as stream:
        def emit(row, terminal=False):
            nonlocal written
            row = dict(row, capture_utc=datetime.datetime.now(datetime.timezone.utc).isoformat(),
                       offset_seconds=time.monotonic() - start)
            text = json.dumps(row, sort_keys=True, allow_nan=False) + '\n'
            size = len(text.encode())
            if not terminal and written + size > MAX_FILE - 4096:
                stats['omitted_events'] += 1
                return False
            stream.write(text)
            written += size
            return True

        digest = hashlib.sha256()
        with real.open('rb') as binary:
            for chunk in iter(lambda: binary.read(1024 * 1024), b''):
                digest.update(chunk)
        emit({'event': 'capture_start', 'schema_version': 1, 'wrapper_pid': os.getpid(),
              'codex_version': '0.163.0', 'executable_sha256': digest.hexdigest(),
              'wrapper_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest(),
              'filter': FILTER, 'raw_stderr_retained': False})
        env = dict(os.environ, RUST_LOG=FILTER, LOG_FORMAT='json')
        try:
            child = subprocess.Popen([str(real), *args], stderr=subprocess.PIPE, env=env)
            emit({'event': 'child_started', 'pid': child.pid})
            if pending_signal:
                child.send_signal(pending_signal)
            # Bounded line parsing: oversize records are drained without accumulation.
            oversized = False
            while True:
                line = child.stderr.readline(MAX_LINE + 1)
                if not line:
                    break
                stats['stderr_bytes'] += len(line)
                if oversized or len(line) > MAX_LINE:
                    if not oversized:
                        stats['oversized_lines'] += 1
                    oversized = not line.endswith(b'\n')
                    continue
                try:
                    row = project(json.loads(line))
                except (ValueError, TypeError, RecursionError, OverflowError):
                    stats['invalid_lines'] += 1
                    continue
                if row is None:
                    stats['ignored_lines'] += 1
                elif emit(row):
                    stats['retained_events'] += 1
            code = child.wait()
            emit(dict(event='capture_end', returncode=code, signal_received=pending_signal, **stats), terminal=True)
            stream.flush()
            os.fsync(stream.fileno())
            return code if code >= 0 else 128 - code
        except BaseException as exc:
            if child is not None and child.poll() is None:
                child.terminate()
                try:
                    child.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    child.kill()
                    child.wait()
            emit(dict(event='capture_failed', error_type=type(exc).__name__, **stats), terminal=True)
            raise
        finally:
            if child is not None and child.stderr:
                child.stderr.close()


if __name__ == '__main__':
    try:
        sys.exit(main())
    except Exception as exc:
        # Do not print exception strings: they can contain paths or protocol bodies.
        print('diagnostic launcher failed: ' + type(exc).__name__, file=sys.stderr)
        sys.exit(125)
